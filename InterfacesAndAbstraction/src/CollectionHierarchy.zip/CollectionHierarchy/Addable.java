package CollectionHierarchy;

public
interface Addable {
    int add(String s);
}

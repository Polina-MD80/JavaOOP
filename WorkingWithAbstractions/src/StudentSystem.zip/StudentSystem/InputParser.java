package StudentSystem;

public
class InputParser {
    public String[] parsData(String string){
        return string.split ("\\s+");
    }
}

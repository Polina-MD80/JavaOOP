package SingleInhetitance;

public
class Animal {
    public void eat(){
        System.out.println ("ating...");
    }
}

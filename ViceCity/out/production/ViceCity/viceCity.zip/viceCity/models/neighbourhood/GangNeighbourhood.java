package viceCity.models.neighbourhood;

import viceCity.models.players.Player;

import java.util.Collection;

public class GangNeighbourhood implements Neighbourhood{

    public GangNeighbourhood() {
    }

    @Override
    public void action(Player mainPlayer, Collection<Player> civilPlayers) {
        boolean civilPlayersAreAllDead = civilPlayers.isEmpty();
        boolean mainPlayerRunOutOffBullets;


    }
}

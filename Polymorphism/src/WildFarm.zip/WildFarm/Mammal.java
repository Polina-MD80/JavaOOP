package WildFarm;

public abstract
class Mammal extends Animal{


    protected
    Mammal (String animalName, String animalType, Double animalWeight, String animalRegion) {
        super (animalName, animalType, animalWeight, animalRegion);
    }



}

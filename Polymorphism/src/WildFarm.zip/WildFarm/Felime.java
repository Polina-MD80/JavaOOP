package WildFarm;

public abstract
class Felime extends Mammal{


    protected
    Felime (String animalName, String animalType, Double animalWeight, String animalRegion) {
        super (animalName, animalType, animalWeight, animalRegion);
    }
}
